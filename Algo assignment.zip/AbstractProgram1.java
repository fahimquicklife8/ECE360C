public abstract class AbstractProgram1 {
    public abstract boolean isStableMatching(Matching problem);

    public abstract Matching stableMatchingGaleShapley_universityoptimal(Matching problem);

    public abstract Matching stableMatchingGaleShapley_studentoptimal(Matching problem);
}

//this is abstract file