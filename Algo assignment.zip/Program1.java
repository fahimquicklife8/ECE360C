/*
 * Name: <Fahim Imtiaz>
 * EID: <fmi89>
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

/**
 * Your solution goes in this class.
 *
 * Please do not modify the other files we have provided for you, as we will use
 * our own versions of those files when grading your project. You are
 * responsible for ensuring that your solution works with the original version
 * of all the other files we have provided for you.
 *
 * That said, please feel free to add additional files and classes to your
 * solution, as you see fit. We will use ALL of your additional files when
 * grading your solution. However, do not add extra import statements to this file.
 */
public class Program1 extends AbstractProgram1 {


    /**
     * Determines whether a candidate Matching represents a solution to the stable matching problem.
     * Study the description of a Matching in the project documentation to help you with this.
     */
    @Override
    public boolean isStableMatching(Matching problem) {
        /* TODO implement this function */
        int m = problem.getUniversityCount();
        int n = problem.getStudentCount();
        ArrayList<Integer> studentMatching = problem.getStudentMatching();
        ArrayList<ArrayList<Integer>> universityPreference = problem.getUniversityPreference();
        ArrayList<ArrayList<Integer>> studentPreference = problem.getStudentPreference();

        for (int i = 0; i < n; i++) {                      //iterate through universities
            int matchedUniversity = studentMatching.get(i);
            ArrayList<Integer> preferredUniversities = studentPreference.get(i);

            for (int j : preferredUniversities) {          //iterate through universities for student preference
                if ( j == matchedUniversity) {
                    break;
                }
                ArrayList<Integer> preferredStudents = universityPreference.get(j);
                int availablePositions = problem.getUniversityPositions().get(j);

                int count = 0;
                for (int k : preferredStudents) {
                    if (k == i) {
                        return false;                   // Unstabel matching
                    }

                    if (studentMatching.get(k) == j) {
                        count++;
                        if (count >= availablePositions) {
                            break;
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * Determines a solution to the stable matching problem from the given input set. Study the
     * project description to understand the variables which represent the input to your solution.
     *
     * @return A stable Matching.
     */
    @Override
    public Matching stableMatchingGaleShapley_universityoptimal(Matching problem) {
        /* TODO implement this function */
        int m = problem.getUniversityCount();
        int n = problem.getStudentCount();
        ArrayList<Integer> universityPositions = problem.getUniversityPositions();
        ArrayList<ArrayList<Integer>> universityPreference = problem.getUniversityPreference();
        ArrayList<Integer> studentMatching = new ArrayList<>();

        // Initialize 'nextToPropose' array to keep track of the next student each university will propose to
        int[] nextToPropose = new int[m];
        Arrays.fill(nextToPropose, 0);

        // Initialize student matching to -1 (ummatched)
        for (int i = 0; i < n; i++) {
            studentMatching.add(-1);
        }

        // Initialize list of free universities
        LinkedList<Integer> freeUniversities = new LinkedList<>();
        for (int i = 0; i < m; i++) {
            freeUniversities.add(i);
        }

        while (!freeUniversities.isEmpty()) {
            int university = freeUniversities.poll();
            ArrayList<Integer> preference = universityPreference.get(university);
            int availablePositions = universityPositions.get(university);

            while (availablePositions > 0 && nextToPropose[university] < n) {
                int student = preference.get(nextToPropose[university]);
                nextToPropose[university]++;                           // Increment index for next propsal
                // Check if student is unmatched or prefers this university over its current match
                if (studentMatching.get(student) == -1) {
                    studentMatching.set(student, university);
                    availablePositions--;
                } else {
                    int matchedUniversity = studentMatching.get(student);
                    ArrayList<Integer> studentPreference = problem.getStudentPreference().get(student);

                    int indexUniversity = -1, indexMatchedUniversity = -1;
                    for (int i = 0; i < studentPreference.size(); i++) {     //manually findind index without indexof
                        if (studentPreference.get(i) == university) {
                            indexUniversity = i;
                        }
                        if (studentPreference.get(i) == matchedUniversity) {
                            indexMatchedUniversity = i;
                        }
                    }

                    if (indexUniversity < indexMatchedUniversity) {
                        studentMatching.set(student, university);
                        availablePositions--;                              //positions decrease
                        universityPositions.set(matchedUniversity, universityPositions.get(matchedUniversity) + 1);
                        freeUniversities.add(matchedUniversity);          // Re-add to free list
                    }
                }
            }

            universityPositions.set(university, availablePositions);
        }

        return new Matching(problem, studentMatching);
    }


    /**
     * Determines a solution to the stable matching problem from the given input set. Study the
     * project description to understand the variables which represent the input to your solution.
     *
     * @return A stable Matching.
     */
    @Override
    public Matching stableMatchingGaleShapley_studentoptimal(Matching problem) {
        /* TODO implement this function */
        int m = problem.getUniversityCount();
        int n = problem.getStudentCount();
        ArrayList<ArrayList<Integer>> studentPreference = problem.getStudentPreference();
        ArrayList<Integer> studentMatching = new ArrayList<>();

        // Initialize student matching to -1 (unmatched)
        for (int i = 0; i < n; i++) {
            studentMatching.add(-1);
        }

        LinkedList<Integer> freeStudents = new LinkedList<>();
        for (int i = 0; i < n; i++) {
            freeStudents.add(i);
        }

        while (!freeStudents.isEmpty()) {
            int student = freeStudents.poll();
            ArrayList<Integer> preference = studentPreference.get(student);

            for (int j : preference) {
                int availablePositions = problem.getUniversityPositions().get(j);

                if (availablePositions > 0) {
                    studentMatching.set(student, j);
                    problem.getUniversityPositions().set(j, availablePositions - 1);
                    break;
                } else {
                    ArrayList<Integer> universityPreference = problem.getUniversityPreference().get(j);
                    int worstMatchIndex = -1;

                    for (int i = universityPreference.size() - 1; i >= 0; i--) {     //itrate through size of pref
                        if (studentMatching.get(universityPreference.get(i)) == j) {
                            worstMatchIndex = i;
                            break;
                        }
                    }

                    int currentStudentIndex = -1;
                    for (int i = 0; i < universityPreference.size(); i++) {
                        if (universityPreference.get(i) == student) {
                            currentStudentIndex = i;
                            break;
                        }
                    }

                    if (currentStudentIndex < worstMatchIndex) {            // check for rank
                        int worstMatchStudent = universityPreference.get(worstMatchIndex);
                        studentMatching.set(worstMatchStudent, -1);
                        studentMatching.set(student, j);
                        freeStudents.add(worstMatchStudent);
                        break;
                    }
                }
            }
        }

        return new Matching(problem, studentMatching);
    }
}


